namespace NewsAI.Dominio.Enums;

public enum EstadoEjecucion
{
    Pendiente,
    Ejecutando,
    Completada,
    Error,
    Cancelada
}
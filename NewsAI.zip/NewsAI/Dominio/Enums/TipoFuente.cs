namespace NewsAI.Dominio.Enums;

public enum TipoFuente
{
    RSS,
    Web,
    API
}
namespace NewsAI.Dominio.Enums;

public enum TipoFrecuencia
{
    Diaria,
    Semanal,
    Mensual,
    Personalizada
}
﻿namespace NewsAI.API.Models;
    public class RssNewsItem
    {
        public string? Titulo { get; set; }
        public string? Resumen { get; set; }
        public string? Link { get; set; }
        public DateTime? FechaPublicacion { get; set; }

    }

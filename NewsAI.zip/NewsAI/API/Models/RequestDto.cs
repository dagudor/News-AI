﻿namespace NewsAI.API.Models;
    public class RequestDto
    {
        public string TextToSummarize { get; set; } = string.Empty;
    }

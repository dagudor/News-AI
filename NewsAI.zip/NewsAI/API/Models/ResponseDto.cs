﻿namespace NewsAI.API.Models;

    public class ResponseDto
    {
        public string TextSummarized { get; set; } = string.Empty;
    }
